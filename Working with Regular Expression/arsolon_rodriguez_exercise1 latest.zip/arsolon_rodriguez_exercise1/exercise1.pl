#!/usr/bin/perl

#programmed by Lovely Grace Arsolon and Icel Ann Rodriguez

use strict;
use warnings;
use diagnostics;

use feature 'say';

my @arr2; #contains the "splitted" texts
my @arr3; 
my @arr4;
my @arr5;

sub tokenizer {
	my ($input) = @_;
	#split input text with special characters except for apostrophe
	my @arr1 = split /[^A-Za-z']/, $input;
	for my $st (@arr1) {
		my $l = length $st;
		if ($l != 0) {
			push @arr2, $st;
		}
	}

	my $l2 = scalar @arr2; 
	for (my $i = 0; $i < $l2; $i++) {
		my $el = $arr2[$i];
		my $dex;
		if ($el =~ m/\s*n't$/i) {
			my $sl = length $el;
			$dex = $sl - 3;

			#pushes substrings
			if ($dex != 0) { 
				if ($el =~ m/\s*n't$/i) { 
					my $len = length $el;
					my $str1 = substr($el, 0, $dex);
					my $str2 = substr($el, $dex, $len - $dex);
					 
					push @arr3, $str1;
					my $c1 = substr($str2, 0, 1);
					my $c2 = substr($str2, 2, 1);
					my $c3 = $c1 . $c2;
					push @arr3, $c3;		
				} else {
					push @arr3, $el;
				}
			} else {
				push @arr3, $el;
			}
		} else {
			push @arr3, $el;
		}

	}

	my $l3 = scalar @arr3;
	for (my $i3 = 0; $i3 < $l3; $i3++) {
		my $el3 = $arr3[$i3];
		my @loc = split /'/, $el3;

		for my $locstr (@loc) {
			push @arr4, $locstr;
		}
	}

	my $l4 = scalar @arr4;
	for (my $i = 0; $i < $l4; $i++) {
		my $str = $arr4[$i];
		if ($str =~ m/gonna$|wanna$|lemme$|gotta$|gimme$/i) {
			my $p1 = substr($str, 0, 3);
			my $p2 = substr($str, 3, 2);
			push @arr5, $p1;
			push @arr5, $p2;
		} 
		else {
			push @arr5, $str;
		}
	}
}

my @temp_arr;
sub found {
	my ($str) = @_;
	my $ans = 0;
	my $str1 = "\\b" . $str . '$';
	for my $tk (@temp_arr) {
		if ($tk =~ m/$str1/i) {
			$ans = 1;;
		}
	}
	return $ans;
}

sub types {
	my (@holder_arr) = @_;

	for my $tok (@holder_arr) { 
		my $isfound = found($tok);
		if ($isfound == 0) {
			push @temp_arr, $tok;
		}
	}
}

sub punctuations {
	#hash array containing the punctuations 
	my %punctuations = (
		"period"=>[".",0],
		"comma"=>[",",0],
		"semi-colon"=>[";",0],
		"colon"=>[":",0],
		"double quote"=>['"',0],
		"exclamation point"=>["!",0],
		"question mark"=>["?",0],
		"open parenthesis"=>["(",0],
		"close parenthesis"=>[")",0],
		"open bracket"=>["[",0],
		"close bracket"=>["]",0],
		"hyphen"=>["-",0],
		"single quote"=>["'",0],
		"open brace"=>["{",0],
		"close brace"=>["}",0],
		"slash"=>["/",0],
	);

	my ($sample_str) = @_;
	my $ss_len = length $sample_str;

	for (my $in = 0; $in < $ss_len; $in++) {
		my $ch = substr($sample_str, $in, 1);
		for my $family (keys %punctuations) {
			my $punc = $punctuations{$family}[0];
			my $cntr = $punctuations{$family}[1];
			if ($ch eq $punc) {
				$cntr++;
				$punctuations{$family}[1] = $cntr;
			}
		}
	}

	say "==================NUMBER  AND TYPES OF PUNCTUATIONS=====================";
	for my $family (keys %punctuations) {
		print "$punctuations{$family}[0] = $punctuations{$family}[1]\n";
	}

	return;
}

sub display {
	say "===============================TOKENS===================================";
	for my $ser (@arr5) {
		say $ser;
	}

	print "\n";
	print "\n";
	my $ll = scalar @arr5;
	say "NUMBER OF TOKENS:  $ll";

	my $ll2 = scalar @temp_arr;
	say "NUMBER OF TYPES:   $ll2";
	print "\n";

	return;
}

sub search {
	my ($str_in) = @_;
	my @holder_arr = split /\s+/, $str_in;

	#asks for user input
	print "\n";
	say "===============================SEARCH===================================";
	say "Enter a word to search:";
	my $str_input = <STDIN>;
	chomp $str_input;

	my $for_ast = "\\S*";
	my $for_qm = "\\S?";
	my $bound = "\\b";

	$str_input =~ s/\*/$for_ast/g;
	$str_input =~ s/\?/$for_qm/g;

	my $word_search = $bound . $str_input . $bound;

	my $flag = 0;
	for my $ind (@holder_arr) {
		if ($ind =~ m/$word_search/g) {
			say "FOUND: $ind";
			$flag = 1;
		}
	}
	if ($flag == 0) {
		say "NOT FOUND!";
	}
}

sub main {
	my $inputtext = "";
	#read input file
	my $file = "input.txt";
	open my $fh, '<', $file or die "Can't Open File : $file";
	while (my $inf = <$fh>) {
	  #chomp($inf);
	  $inputtext .= $inf;
	}
	close $fh or die "Couldn't Close file : $file";

	# say $inputtext;
	tokenizer($inputtext);
	types(@arr5);
	display();
	punctuations($inputtext);

	my $in = "1";;
	while ($in ne "0") {
		if ($in =~ m/0/g) {
			return;
		} else {
			search($inputtext);
			say "Press zero (0) then ENTER to exit. Press ENTER to continue.";
			my $choice = <STDIN>;
			$in = $choice;
		}
	}
	return;
}

main();